import os
import argparse
from mip import solution_model
from mip import solution_model_rotation
from smt import smt_model_no_rotation, smt_model_rotation
from glob import glob
import smt


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("-i", "--input_dir", help="Path to the directory containing the initial instances",
                        required=False, type=str, default="../../instances/txt")
    parser.add_argument("-o", "--output_dir",
                        help="Path to the directory that will contain the output solutions in .txt format",
                        required=False, type=str, default="../out")
    parser.add_argument("-f", "--figures_dir",
                        help = "Path to the directory that will contain the plotted solutions",
                        required = False, type = str, default = "../figures")
    parser.add_argument('-m', '--model',
                        help = "Choose with what approach you want to solve this problem, either smt or mip.",
                        required = True, type = str, default = 'smt')
    parser.add_argument("-s", "--solver",
                        help = "Choose the solver, either select cplex, gurobi or pulp",
                        required = True, type = str, default = "cplex")
    parser.add_argument('-c', '--cplex',
                        help = "Choose CPLEX path",
                        required = False, type = str, default = "'C:/Program Files/IBM/ILOG/CPLEX_Studio221/cplex/bin/x64_win64/cplex.exe'")
    parser.add_argument("-r", "--rotation", help="Flag to decide whether it is possible to use rotated circuits",
                        required=False, action='store_true', default=False)
    parser.add_argument('-sym', "--symmetry", help = "Flag to decide whether the problem will be solved using symmetry breaking constraints or not",
                        required = False, action = 'store_true', default = True)
    parser.add_argument("-p", "--plots", help="Whether to save the plots",
                        required=False, action='store_true', default=False)
    args = parser.parse_args()
    print(args)


    input_dir = args.input_dir
    output_dir = args.output_dir
    fig_dir = args.figures_dir
    solver = args.solver
    cplex_path = args.cplex

    if os.path.exists(output_dir) is False:
        os.makedirs(output_dir)

    if os.path.exists(fig_dir) is False:
        os.makedirs(fig_dir)

    for i in range(len(glob(os.path.join(input_dir, '*.txt')))):
        in_file = os.path.join(input_dir, f'ins-{i+1}.txt')
        print(f'\n\n SOLVING INSTANCE {i+1}:')
        if args.model.lower() == 'smt':
            if args.rotation:
                if args.symmetry:
                    smt_model_rotation.solve_problem(in_file, output_dir, fig_dir, i + 1, args.solver, symmetry = True, timeout = 300)
                else:
                    smt_model_rotation.solve_problem(in_file, output_dir, fig_dir, i+1, args.solver, symmetry = False, timeout = 300)
            else:
                if args.symmetry:
                    smt_model_no_rotation.solve_problem(in_file,output_dir, fig_dir, i+1, args.solver, symmetry = True, timeout = 300)
                else:
                    smt_model_no_rotation.solve_problem(in_file, output_dir, fig_dir, i + 1, args.solver, symmetry = False, timeout = 300)
        if args.model.lower() == 'mip':
            if args.rotation:
                if args.symmetry:
                    solution_model_rotation.solve_problem(in_file, output_dir, fig_dir, i+1, args.solver, symmetry = True, timeout = 300)
                else:
                    solution_model_rotation.solve_problem(in_file, output_dir, fig_dir, i+1, args.solver, symmetry = False, timeout = 300)
            else:
                if args.symmetry:
                    solution_model.solve_problem(in_file, output_dir, fig_dir, i+1, args.solver, symmetry = True, timeout = 300)
                else:
                    solution_model.solve_problem(in_file, output_dir, fig_dir, i+1, args.solver, symmetry = False, timeout = 300)

if __name__ == '__main__':
    main()