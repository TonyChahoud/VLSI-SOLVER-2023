# ============= COMMON PARAMETERS =============

DISP = True
ROT = True

# NB: relative to the file that import this one:
INST_PATH = '../../instances/'
SOL_PATH = '../out/rotation/' if ROT else '../out/basic/'


print(f'ROTATION: {ROT}\n')
