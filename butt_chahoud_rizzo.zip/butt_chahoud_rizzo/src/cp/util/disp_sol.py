import drawSvg as draw
import sys
import random

def create_svg(fname):
    with open(fname, 'r') as f:
        ill = [ [int(_)  for _ in l.split()] for l in f.readlines() ]

    w, h = ill[0]
    d = draw.Drawing(w*10, h*10 + 8, displayInline=False, background='black')
    d.append(draw.Rectangle(0,h*10,w*10,8,stroke='black',stroke_width=0,fill='black')) #stroke_opacity=0.07)
    d.append(draw.Text(f'<{w},{h}> - {len(ill[2:])} components', 6, 2, h*10+2, fill='white'))

    for i,(wb,hb,x,y) in enumerate(ill[2:]):
        # print(wb,hb,x,y)
        ran = int(random.uniform(0,120))
        r = draw.Rectangle(x*10,y*10,wb*10,hb*10, stroke='red', stroke_width=1, fill=f'#0000{ran:02X}') #i*SEP%120
        d.append(r)
        d.append(draw.Text(str(i+1), 6, x*10+2, y*10+2, fill='white'))

    for x in range(0,w):
        for y in range(0,h):
            d.append(draw.Rectangle(x*10,y*10,10,10,stroke='gray',stroke_width=1,fill='none',stroke_opacity=0.07))

    d.saveSvg(f'{fname}.svg')
