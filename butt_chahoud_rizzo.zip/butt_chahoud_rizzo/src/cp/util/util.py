from time import monotonic as clock
import os, re, sys
from disp_sol import create_svg
import multiprocessing as mp


def timed(F, *args, **kargs):
    ''' Returns the result of the exec. of F(*args, **kargs),
    along with time spent for the exec.'''
    t = clock()
    result = F(*args, **kargs)
    return result, clock()-t


def parse(fname, rotation=False):
    '''
    To parse the given instance file and return a dict with keys:
    w: the width
    N: the n. of circuits
    x: the tuple of x dimensions of the circuits
    y: the tuple of y dimensions of the circuits
    '''
    with open(fname, 'r') as f: l = [ [int(_)  for _ in l.split()] for l in f.readlines() ]
    x, y = list(zip(*list([(_[0], _[1]) for _ in l[2:]])))
    return {'w':l[0][0], 'N':l[1][0], 'x_dim_orig':x, 'y_dim_orig':y} if rotation else \
        {'w':l[0][0], 'N':l[1][0], 'x':x, 'y':y}


def load_instance_numbers(L, from_where):
    '''
    Checks if the instance numbers in L[1:] correspond to real instance files in the path
    "from_where" and returns the int conversion of L[1:]. If L is empty returns the list
    of instance numbers which correspondent file exists in from_where.
    '''
    from os.path import abspath
    try:
        ALL = sorted([ int(re.fullmatch(r'ins-(\d+).txt', _).group(1)) for _ in os.listdir(abspath(from_where)) ])
        if len(L)>1:
            nn = [int(_) for _ in L[1:]]
            if set(nn).issubset(set(ALL)): return nn
            else: 
                print("Invalid instance number(s) for the specified src folder.\nQuitting!")
                sys.exit(-1)
        else: return ALL
    except AttributeError:
        print("Invalid input instance name in src folder.\nQuitting!")
        sys.exit(-1)

def save_sol_file(fname, w, sol, POS_LIST, create_image):
    '''
    Create a sol. file (and an image when create_image=True), given:
    w: the width
    sol: the height
    POS_LIST: a list whose elem. are strings in the form 'd1 d2 x y' where d1,d2
        are the x,y circuit dimensions and x,y the 0-based position of the circuit
    '''
    with open(fname,'w') as sol_file:
        sol_file.write(f"{w} {sol}\n{len(POS_LIST)}\n"+'\n'.join(POS_LIST))
    if create_image:
        print(end='  Generating image...', flush=True)
        create_svg(fname)
        print(' done')


def secs(i):
    from datetime import timedelta
    return timedelta(seconds=i)


def run_for(fun, *args, timeo=0, **kargs):
    q = mp.Queue()
    def f(q):
        q.put( timed(fun, *args, **kargs) )
    p = mp.Process(target=f, args=(q,), name='f')
    p.start()
    p.join(timeout=timeo)
    p.terminate()
    return (('global_timeout',),timeo) if p.exitcode==None else q.get()
    
